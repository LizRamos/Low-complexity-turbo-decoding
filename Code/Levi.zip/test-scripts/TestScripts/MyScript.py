import sys
### This is just a dummy python script that prints back to the shell
print "This is a test python script"
print "This is the argument I passed in:"
print sys.argv[1]
